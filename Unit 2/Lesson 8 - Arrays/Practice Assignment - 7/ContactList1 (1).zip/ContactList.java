public class ContactList
{
     private Person[] contacts;
     private int numberPeople;
     final private int BOOK_SIZE;
     
     public ContactList()
     {
          contacts = new Person[100];
          numberPeople = 0;
          BOOK_SIZE = 100;
     }
     
     public ContactList(int size)
     {
          contacts = new Person[size];
          numberPeople = 0;
          BOOK_SIZE = size;
     }
     
     public void addPerson(String firstName, String lastName, int age, String phoneNumber, int grade)
     {
          Person newPerson = new Person(firstName, lastName, age, phoneNumber, grade);
          
          if(numberPeople <BOOK_SIZE)
          {
               contacts[numberPeople] = newPerson;
               numberPeople++;
          }
          else
          {
               System.out.println("Your book is full.  You must first delete a person before adding a new one.");
          }
     }
     
     public void removePerson(int personIndex)
     {
          for(int x = personIndex; x<numberPeople-1; x++)
          {
               contacts[x] = contacts[x+1];
          }
          contacts[numberPeople-1] = null;
          numberPeople--;
     }
     
     public void displayBook()
     {
          System.out.printf("%-4s%-12s%-15s%-4s%-13s%-9s%n","Pos","First Name","Last Name","Age","Phone Number","Grade");
          for(int x = 0; x<numberPeople; x++)
          {
               System.out.printf("%-4d%-12s%-15s%-4d%-13s%-9d%n",x+1,contacts[x].getFirstName(),contacts[x].getLastName(),contacts[x].getAge(),
                                 contacts[x].getPhoneNumber(),contacts[x].getGrade());
          }
     }
     
     public void changeGrade(int personIndex, int newGrade)
     {
          contacts[personIndex-1].setGrade(newGrade);
     }
}