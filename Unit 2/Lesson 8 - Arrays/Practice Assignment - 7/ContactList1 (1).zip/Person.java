public class Person
{
     private String firstName;
     private String lastName;
     private int age;
     private String phoneNumber;
     private int grade;
     
     public Person(String firstName, String lastName, int age, String phoneNumber, int grade)
     {
          this.firstName = firstName;
          this.lastName = lastName;
          this.age = age;
          this.phoneNumber = phoneNumber;
          this.grade = grade;
     }
     
     public void setGrade(int newGrade)
     {
          this.grade = newGrade;
     }
     
     public String getFirstName()
     {
          return this.firstName;
     }
     
     public String getLastName()
     {
          return this.lastName;
     }
     
     public int getAge()
     {
          return this.age;
     }
     
     public String getPhoneNumber()
     {
          return this.phoneNumber;
     }
     
     public int getGrade()
     {
          return this.grade;
     }
}